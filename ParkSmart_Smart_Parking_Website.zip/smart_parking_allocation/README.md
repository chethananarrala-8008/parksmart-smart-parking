# ParkSmart — Smart Parking Allocation System

A responsive Python Flask website for the Parking Slot Allocation System problem statement.

## Features
- Professional dashboard with live slot counts and occupancy.
- Vehicle booking form for cars, bikes, and electric vehicles.
- Greedy, priority-based compatible slot allocation.
- SQLite database for slots and booking history.
- Release booking action and resettable demo parking area.
- Simple demand forecast indicator based on current occupancy and recent booking volume.
- Responsive layout for laptop, tablet, and mobile.

## Requirements
- Python 3.10 or newer
- Internet connection only if you want the optional Google Fonts to load; the site otherwise works without them.

## Run on Windows
1. Extract the ZIP file.
2. Open the extracted `smart_parking_allocation` folder.
3. Click the folder address bar in File Explorer, type `cmd`, and press Enter.
4. Create a virtual environment (recommended):
   ```bat
   py -m venv venv
   venv\\Scripts\\activate
   ```
5. Install Flask:
   ```bat
   pip install -r requirements.txt
   ```
6. Start the website:
   ```bat
   python app.py
   ```
7. Open this address in your browser:
   `http://127.0.0.1:5000`

The `parking.db` database is created automatically on first run.

## How the algorithm works
1. Read the incoming vehicle type.
2. Find unoccupied slots compatible with that type (exact type or a car-compatible slot).
3. Sort by priority, highest first, then by slot code.
4. Assign the first slot and mark it occupied.
5. When a booking is released, mark the slot available again.

## Forecasting note
The forecast is a small, transparent demonstration using current occupancy and the last seven days of booking records. For a real deployment, collect time-stamped occupancy data over weeks or months and train/evaluate a forecasting model. The demo forecast should not be presented as a validated prediction model.

## Suggested project explanation
- **Problem:** Drivers waste time and fuel searching for parking.
- **Solution:** Automatically assign compatible spaces and display availability.
- **Algorithm:** Greedy allocation with priority ranking.
- **OOP:** The implementation includes `Vehicle`, `ParkingSlot`, `ParkingLot`, and `ParkingManager` classes. `ParkingManager` coordinates allocation, `ParkingLot` selects the best slot, and `ParkingSlot` checks compatibility.
- **Limitations:** Demo slots are seeded locally; no live sensors, payments, user accounts, or multi-user production safeguards are included.
