// Small client-side helpers for a smoother demo experience.
document.addEventListener("DOMContentLoaded", () => {
  const vehicleInput = document.querySelector("#vehicle_number");
  if (vehicleInput) {
    vehicleInput.addEventListener("input", () => {
      vehicleInput.value = vehicleInput.value.toUpperCase();
    });
  }

  // Hide status messages after a few seconds.
  document.querySelectorAll(".flash").forEach((message) => {
    window.setTimeout(() => {
      message.style.transition = "opacity .35s ease";
      message.style.opacity = "0";
      window.setTimeout(() => message.remove(), 400);
    }, 5000);
  });
});
