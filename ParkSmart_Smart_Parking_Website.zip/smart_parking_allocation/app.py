from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("parking.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS slots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slot_code TEXT UNIQUE NOT NULL,
                slot_type TEXT NOT NULL,
                priority INTEGER NOT NULL DEFAULT 1,
                is_occupied INTEGER NOT NULL DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS bookings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vehicle_number TEXT NOT NULL,
                vehicle_type TEXT NOT NULL,
                arrival_time TEXT NOT NULL,
                duration_hours REAL NOT NULL,
                slot_id INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'Active',
                created_at TEXT NOT NULL,
                FOREIGN KEY(slot_id) REFERENCES slots(id)
            )
        """)
        count = conn.execute("SELECT COUNT(*) AS n FROM slots").fetchone()["n"]
        if count == 0:
            seed = []
            for i in range(1, 13):
                seed.append((f"A{i:02d}", "Car", 2 if i <= 3 else 1, 0))
            for i in range(1, 5):
                seed.append((f"B{i:02d}", "Bike", 1, 0))
            for i in range(1, 3):
                seed.append((f"EV{i:02d}", "EV", 3, 0))
            conn.executemany(
                "INSERT INTO slots (slot_code, slot_type, priority, is_occupied) VALUES (?, ?, ?, ?)",
                seed
            )


class Vehicle:
    """Represents an incoming vehicle requesting a parking space."""
    def __init__(self, registration_number, vehicle_type, duration_hours):
        self.registration_number = registration_number
        self.vehicle_type = vehicle_type
        self.duration_hours = duration_hours


class ParkingSlot:
    """Object model for one parking slot."""
    def __init__(self, slot_id, slot_code, slot_type, priority, is_occupied):
        self.id = slot_id
        self.slot_code = slot_code
        self.slot_type = slot_type
        self.priority = priority
        self.is_occupied = bool(is_occupied)

    def can_fit(self, vehicle):
        return (not self.is_occupied and
                (self.slot_type == vehicle.vehicle_type or self.slot_type == "Car"))


class ParkingLot:
    """Contains slots and applies the greedy priority-based selection."""
    def __init__(self, slots):
        self.slots = slots

    def find_best_slot(self, vehicle):
        compatible = [slot for slot in self.slots if slot.can_fit(vehicle)]
        compatible.sort(key=lambda slot: (-slot.priority, slot.slot_code))
        return compatible[0] if compatible else None


class ParkingManager:
    """Coordinates database records and parking allocation."""
    def allocate(self, vehicle):
        with get_db() as conn:
            rows = conn.execute("SELECT * FROM slots WHERE is_occupied = 0").fetchall()
        slot_objects = [
            ParkingSlot(row["id"], row["slot_code"], row["slot_type"],
                        row["priority"], row["is_occupied"])
            for row in rows
        ]
        chosen = ParkingLot(slot_objects).find_best_slot(vehicle)
        if chosen is None:
            return None
        with get_db() as conn:
            conn.execute("UPDATE slots SET is_occupied = 1 WHERE id = ?", (chosen.id,))
        return chosen


def recommend_slot(vehicle_type, vehicle_number="", duration_hours=1):
    """Create a Vehicle object and allocate a compatible slot through OOP classes."""
    vehicle = Vehicle(vehicle_number, vehicle_type, duration_hours)
    return ParkingManager().allocate(vehicle)


def dashboard_data():
    with get_db() as conn:
        slots = conn.execute("SELECT * FROM slots ORDER BY slot_code").fetchall()
        bookings = conn.execute("""
            SELECT b.*, s.slot_code
            FROM bookings b JOIN slots s ON b.slot_id = s.id
            WHERE b.status = 'Active'
            ORDER BY b.id DESC
        """).fetchall()
        total = conn.execute("SELECT COUNT(*) n FROM slots").fetchone()["n"]
        occupied = conn.execute("SELECT COUNT(*) n FROM slots WHERE is_occupied = 1").fetchone()["n"]
        vehicle_count = conn.execute("SELECT COUNT(*) n FROM bookings WHERE status = 'Active'").fetchone()["n"]
        history = conn.execute("""
            SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS total
            FROM bookings GROUP BY day ORDER BY day DESC LIMIT 7
        """).fetchall()
    occupancy = round((occupied / total) * 100) if total else 0
    # A simple demo forecast based on current occupancy and recent booking volume.
    recent_bookings = sum(row["total"] for row in history)
    if occupancy >= 80 or recent_bookings >= 10:
        forecast = "High"
        forecast_note = "Demand may be near peak. Consider reserving early."
    elif occupancy >= 50 or recent_bookings >= 5:
        forecast = "Moderate"
        forecast_note = "Demand is steady. Some slots may fill soon."
    else:
        forecast = "Low"
        forecast_note = "Parking demand currently looks manageable."
    return slots, bookings, total, occupied, vehicle_count, occupancy, forecast, forecast_note


@app.route("/")
def index():
    data = dashboard_data()
    return render_template("index.html", slots=data[0], bookings=data[1],
                           total=data[2], occupied=data[3], active_vehicles=data[4],
                           occupancy=data[5], forecast=data[6], forecast_note=data[7],
                           now=datetime.now().strftime("%Y-%m-%dT%H:%M"))


@app.route("/book", methods=["POST"])
def book():
    vehicle_number = request.form.get("vehicle_number", "").strip().upper()
    vehicle_type = request.form.get("vehicle_type", "Car")
    arrival_time = request.form.get("arrival_time", "").strip()
    try:
        duration = float(request.form.get("duration_hours", "1"))
    except ValueError:
        duration = 0

    if not vehicle_number or not arrival_time or duration <= 0 or duration > 48:
        flash("Enter a vehicle number, arrival time, and duration between 0 and 48 hours.", "error")
        return redirect(url_for("index"))

    slot = recommend_slot(vehicle_type, vehicle_number, duration)
    if not slot:
        flash("No compatible slot is available right now. Please try another vehicle type or release a slot.", "error")
        return redirect(url_for("index"))

    with get_db() as conn:
        conn.execute("""
            INSERT INTO bookings (vehicle_number, vehicle_type, arrival_time, duration_hours,
                                  slot_id, status, created_at)
            VALUES (?, ?, ?, ?, ?, 'Active', ?)
        """, (vehicle_number, vehicle_type, arrival_time, duration, slot.id,
              datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    flash(f"Booking confirmed! Slot {slot.slot_code} has been allocated to {vehicle_number}.", "success")
    return redirect(url_for("index"))


@app.route("/release/<int:booking_id>", methods=["POST"])
def release(booking_id):
    with get_db() as conn:
        booking = conn.execute(
            "SELECT slot_id FROM bookings WHERE id = ? AND status = 'Active'", (booking_id,)
        ).fetchone()
        if booking:
            conn.execute("UPDATE bookings SET status = 'Completed' WHERE id = ?", (booking_id,))
            conn.execute("UPDATE slots SET is_occupied = 0 WHERE id = ?", (booking["slot_id"],))
            flash("Parking slot released successfully.", "success")
        else:
            flash("That active booking could not be found.", "error")
    return redirect(url_for("index"))


@app.route("/reset", methods=["POST"])
def reset_demo():
    with get_db() as conn:
        conn.execute("UPDATE bookings SET status = 'Completed' WHERE status = 'Active'")
        conn.execute("UPDATE slots SET is_occupied = 0")
    flash("Demo parking area reset. All slots are available.", "success")
    return redirect(url_for("index"))


init_db()

if __name__ == "__main__":
    app.run(debug=True)
